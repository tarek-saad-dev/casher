/**
 * Phase 1A — Canonical employee day-plan reader.
 *
 * Same weekly windows + overrides + freelance unlock + overnight semantics as
 * bookingAvailabilityEngine. Flow-board and scheduleIntegrity must consume this
 * instead of independent TblEmpWorkSchedule / getBarberWorkingWindow paths.
 */

import type { Transaction } from 'mssql';
import { getPool, sql } from '@/lib/db';
import {
  applyOverrides,
  type EffectiveSchedule,
  type ScheduleOverride,
} from '@/lib/scheduleOverrides';
import { loadBookingOverridesForDate } from '@/lib/hr/attendance-shift-schedule-sync';
import { loadFreelanceBookingUnlocks } from '@/lib/hr/freelanceBookingUnlock';
import {
  loadWorkingWindowsBatch,
  type WorkingWindowRow,
} from '@/lib/availability/loadWorkingWindowsBatch';
import {
  type AvailabilityReasonCode,
  inferDayDenyReason,
} from '@/lib/availability/reasonCodes';
import { salonDateTimeToMs, getGlobalTimingDefaults } from '@/lib/publicBookingHelpers';
import { SALON_TZ } from '@/lib/businessDate';

export type DayPlanWindow = {
  start: string;
  end: string;
  endDayOffset: 0 | 1;
  startMs: number;
  endMs: number;
};

export type DayPlanAttendanceState = {
  status: string | null;
  checkInTime: string | null;
  checkOutTime: string | null;
};

export type EmployeeDayPlan = {
  employeeId: number;
  branchId: number | null;
  businessDate: string;
  isWorking: boolean;
  effectiveWindows: DayPlanWindow[];
  baseScheduleSource:
    | 'BRANCH_WEEKLY'
    | 'LEGACY_WEEKLY'
    | 'TEMPORARY_TRANSFER'
    | 'FREELANCE_UNLOCK'
    | 'NONE';
  weeklyWindows: WorkingWindowRow | null;
  appliedOverrides: ScheduleOverride[];
  attendanceState: DayPlanAttendanceState | null;
  denyReasonCode: AvailabilityReasonCode | null;
  warnings: string[];
  /** Effective schedule after applyOverrides (for integrity parity). */
  effSched: EffectiveSchedule | null;
  isOvernight: boolean;
};

function hhmmToMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

function nextDate(dateStr: string): string {
  const d = new Date(`${dateStr}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
}

function mapSource(
  weekly: WorkingWindowRow | null,
  freelance: boolean,
): EmployeeDayPlan['baseScheduleSource'] {
  if (freelance) return 'FREELANCE_UNLOCK';
  if (!weekly) return 'NONE';
  return weekly.source ?? (weekly.isWorkingDay ? 'BRANCH_WEEKLY' : 'NONE');
}

async function loadAttendanceState(
  db: Awaited<ReturnType<typeof getPool>>,
  empId: number,
  businessDate: string,
): Promise<DayPlanAttendanceState | null> {
  try {
    const res = await db
      .request()
      .input('empId', sql.Int, empId)
      .input('workDate', sql.Date, businessDate)
      .query(`
        SELECT TOP 1 Status,
          CASE WHEN CheckInTime IS NOT NULL THEN LEFT(CONVERT(VARCHAR(8), CheckInTime, 108), 5) ELSE NULL END AS CheckInTime,
          CASE WHEN CheckOutTime IS NOT NULL THEN LEFT(CONVERT(VARCHAR(8), CheckOutTime, 108), 5) ELSE NULL END AS CheckOutTime
        FROM dbo.TblEmpAttendance
        WHERE EmpID = @empId AND WorkDate = @workDate
      `);
    const row = res.recordset[0];
    if (!row) return null;
    return {
      status: row.Status ?? null,
      checkInTime: row.CheckInTime ?? null,
      checkOutTime: row.CheckOutTime ?? null,
    };
  } catch {
    return null;
  }
}

async function loadDayOffAbsentFlags(
  db: Awaited<ReturnType<typeof getPool>>,
  empId: number,
  businessDate: string,
): Promise<{ dayOff: boolean; absent: boolean }> {
  let dayOff = false;
  let absent = false;
  try {
    const doRes = await db
      .request()
      .input('empId', sql.Int, empId)
      .input('offDate', sql.Date, businessDate)
      .query(`
        SELECT TOP 1 1 AS X FROM dbo.TblEmpDayOff
        WHERE EmpID = @empId AND OffDate = @offDate AND IsDeleted = 0
      `);
    dayOff = doRes.recordset.length > 0;
  } catch {
    /* optional */
  }
  try {
    const attRes = await db
      .request()
      .input('empId', sql.Int, empId)
      .input('workDate', sql.Date, businessDate)
      .query(`
        SELECT TOP 1 1 AS X FROM dbo.TblEmpAttendance
        WHERE EmpID = @empId AND WorkDate = @workDate AND Status = N'Absent'
      `);
    absent = attRes.recordset.length > 0;
  } catch {
    /* optional */
  }
  return { dayOff, absent };
}

function buildWorkingPlanSync(args: {
  empId: number;
  branchId: number | null;
  businessDate: string;
  weekly: WorkingWindowRow;
  baseScheduleSource: EmployeeDayPlan['baseScheduleSource'];
  effSched: EffectiveSchedule;
  overrides: ScheduleOverride[];
  attendanceState: DayPlanAttendanceState | null;
  warnings: string[];
  timezone: string;
}): EmployeeDayPlan {
  const start = args.effSched.start;
  const end = args.effSched.end;
  const isOvernight = hhmmToMinutes(end) <= hhmmToMinutes(start);
  const startMs = salonDateTimeToMs(args.businessDate, start, args.timezone);
  const endMs = isOvernight
    ? salonDateTimeToMs(nextDate(args.businessDate), end, args.timezone)
    : salonDateTimeToMs(args.businessDate, end, args.timezone);

  return {
    employeeId: args.empId,
    branchId: args.branchId,
    businessDate: args.businessDate,
    isWorking: true,
    effectiveWindows: [
      {
        start,
        end,
        endDayOffset: isOvernight ? 1 : 0,
        startMs,
        endMs,
      },
    ],
    baseScheduleSource: args.baseScheduleSource,
    weeklyWindows: args.weekly,
    appliedOverrides: args.overrides,
    attendanceState: args.attendanceState,
    denyReasonCode: null,
    warnings: args.warnings,
    effSched: args.effSched,
    isOvernight,
  };
}

export async function resolveEmployeeDayPlan(args: {
  branchId?: number | null;
  empId: number;
  businessDate: string;
  source?: 'public' | 'operations' | 'admin';
  transaction?: Transaction;
}): Promise<EmployeeDayPlan> {
  const { empId, businessDate } = args;
  const branchId = args.branchId ?? null;
  const warnings: string[] = [];
  // Transaction shares request API with pool for these reads.
  const db = (args.transaction ?? (await getPool())) as Awaited<ReturnType<typeof getPool>>;
  const dayOfWeek = new Date(`${businessDate}T12:00:00Z`).getDay();
  const settings = await getGlobalTimingDefaults();
  const timezone = settings.timezone || SALON_TZ;

  const [windowsMap, overridesMap, freelanceUnlocks, attendanceState, flags] = await Promise.all([
    loadWorkingWindowsBatch(db, [empId], dayOfWeek, {
      branchId: branchId ?? undefined,
      workDate: businessDate,
    }),
    loadBookingOverridesForDate(db, [empId], businessDate),
    loadFreelanceBookingUnlocks([empId], businessDate),
    loadAttendanceState(db, empId, businessDate),
    loadDayOffAbsentFlags(db, empId, businessDate),
  ]);

  let weekly: WorkingWindowRow | null = windowsMap.get(empId) ?? null;
  let freelanceApplied = false;

  if (flags.dayOff || flags.absent) {
    return {
      employeeId: empId,
      branchId,
      businessDate,
      isWorking: false,
      effectiveWindows: [],
      baseScheduleSource: mapSource(weekly, false),
      weeklyWindows: weekly,
      appliedOverrides: overridesMap.get(empId) ?? [],
      attendanceState,
      denyReasonCode: inferDayDenyReason({
        contextsEmpty: true,
        specificEmp: true,
        dayOff: flags.dayOff,
        absent: flags.absent,
      }),
      warnings,
      effSched: null,
      isOvernight: false,
    };
  }

  const unlock = freelanceUnlocks.get(empId);
  if (unlock && !weekly?.isWorkingDay) {
    weekly = {
      isWorkingDay: true,
      startTime: unlock.start,
      endTime: unlock.end,
      source: 'LEGACY_WEEKLY',
    };
    freelanceApplied = true;
  }

  if (!weekly) {
    return {
      employeeId: empId,
      branchId,
      businessDate,
      isWorking: false,
      effectiveWindows: [],
      baseScheduleSource: 'NONE',
      weeklyWindows: null,
      appliedOverrides: overridesMap.get(empId) ?? [],
      attendanceState,
      denyReasonCode: 'SCHEDULE_NOT_CONFIGURED',
      warnings,
      effSched: null,
      isOvernight: false,
    };
  }

  const overrides = overridesMap.get(empId) ?? [];
  const base = {
    isWorking: !!weekly.isWorkingDay,
    start: weekly.startTime ?? '00:00',
    end: weekly.endTime ?? '00:00',
  };
  const effSched = applyOverrides(empId, businessDate, base, overrides);
  const baseScheduleSource = mapSource(weekly, freelanceApplied);

  if (!effSched.isWorking) {
    return {
      employeeId: empId,
      branchId,
      businessDate,
      isWorking: false,
      effectiveWindows: [],
      baseScheduleSource,
      weeklyWindows: weekly,
      appliedOverrides: overrides,
      attendanceState,
      denyReasonCode: weekly.isWorkingDay ? 'EMPLOYEE_OFF_DAY' : 'EMPLOYEE_OFF_DAY',
      warnings,
      effSched,
      isOvernight: false,
    };
  }

  if (!weekly.startTime && !effSched.start) {
    return {
      employeeId: empId,
      branchId,
      businessDate,
      isWorking: false,
      effectiveWindows: [],
      baseScheduleSource,
      weeklyWindows: weekly,
      appliedOverrides: overrides,
      attendanceState,
      denyReasonCode: 'SCHEDULE_NOT_CONFIGURED',
      warnings,
      effSched,
      isOvernight: false,
    };
  }

  return buildWorkingPlanSync({
    empId,
    branchId,
    businessDate,
    weekly,
    baseScheduleSource,
    effSched,
    overrides,
    attendanceState,
    warnings,
    timezone,
  });
}

/** Batch helper for flow-board — one date, many employees. */
export async function resolveEmployeeDayPlansBatch(args: {
  branchId?: number | null;
  empIds: number[];
  businessDate: string;
  source?: 'public' | 'operations' | 'admin';
}): Promise<Map<number, EmployeeDayPlan>> {
  const out = new Map<number, EmployeeDayPlan>();
  if (!args.empIds.length) return out;
  await Promise.all(
    args.empIds.map(async (empId) => {
      const plan = await resolveEmployeeDayPlan({
        branchId: args.branchId,
        empId,
        businessDate: args.businessDate,
        source: args.source,
      });
      out.set(empId, plan);
    }),
  );
  return out;
}
